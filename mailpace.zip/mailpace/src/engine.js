// The "intelligent" sending engine.
//
// On every tick it walks each ACTIVE mailbox and decides whether that mailbox
// may send one email right now. A mailbox sends only if:
//   1. it is past its randomized "next due" time   -> human-like pacing
//   2. it is under its effective daily cap          -> throttling + warmup ramp
// Because we loop mailbox-by-mailbox and pull the oldest queued message from
// any running campaign, load naturally spreads across mailboxes -> rotation.
import { db, nowIso, sentTodayCount, effectiveDailyCap } from './db.js';
import { sendEmail } from './mailer.js';

let timer = null;
let running = true;   // engine paused/running toggle
let ticking = false;  // re-entrancy guard
let lastTickAt = null;

const randInt = (min, max) => Math.floor(min + Math.random() * (max - min + 1));

// Replace {{first_name}} style tokens with lead data. Unknown/empty -> ''.
export function renderTemplate(tpl, lead) {
  const map = {
    first_name: lead.first_name,
    last_name: lead.last_name,
    company: lead.company,
    email: lead.email,
  };
  return String(tpl || '').replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => {
    const v = map[key];
    return v === undefined || v === null ? '' : String(v);
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

function textToHtml(text) {
  return `<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.55;white-space:pre-wrap">${escapeHtml(
    text
  )}</div>`;
}

// Reset anything left mid-flight by a crash/restart so it can be retried.
export function recoverStuck() {
  const r = db.prepare(`UPDATE messages SET status='queued' WHERE status='sending'`).run();
  if (r.changes) console.log(`[engine] recovered ${r.changes} stuck message(s)`);
}

// Pull the oldest queued message belonging to any RUNNING campaign.
function nextQueuedMessage() {
  return db
    .prepare(
      `SELECT m.* FROM messages m
       JOIN campaigns c ON c.id = m.campaign_id
       WHERE m.status = 'queued' AND c.status = 'running'
       ORDER BY m.id ASC
       LIMIT 1`
    )
    .get();
}

function markCompletedCampaigns() {
  const running = db.prepare(`SELECT id FROM campaigns WHERE status='running'`).all();
  for (const { id } of running) {
    const left = db
      .prepare(`SELECT COUNT(*) AS c FROM messages WHERE campaign_id = ? AND status IN ('queued','sending')`)
      .get(id).c;
    if (left === 0) db.prepare(`UPDATE campaigns SET status='completed' WHERE id = ?`).run(id);
  }
}

async function sendOneFor(acc) {
  const msg = nextQueuedMessage();
  if (!msg) return false; // nothing queued anywhere

  const lead = db.prepare(`SELECT * FROM leads WHERE id = ?`).get(msg.lead_id);
  const campaign = db.prepare(`SELECT * FROM campaigns WHERE id = ?`).get(msg.campaign_id);
  const subject = renderTemplate(campaign.subject, lead);
  const text = renderTemplate(campaign.body, lead);

  // Atomically claim the message so no other mailbox grabs it.
  const claim = db
    .prepare(`UPDATE messages SET status='sending', account_id=? WHERE id=? AND status='queued'`)
    .run(acc.id, msg.id);
  if (claim.changes === 0) return false; // someone else took it

  try {
    const res = await sendEmail(acc, { to: lead.email, subject, text, html: textToHtml(text) });
    db.prepare(
      `UPDATE messages SET status='sent', sent_at=?, subject=?, body=?, preview_url=?, error=NULL WHERE id=?`
    ).run(nowIso(), subject, text, res.preview, msg.id);

    const gapMs = randInt(acc.min_gap_seconds, acc.max_gap_seconds) * 1000;
    const next = new Date(Date.now() + gapMs).toISOString();
    db.prepare(`UPDATE accounts SET last_sent_at=?, next_due_at=?, last_error=NULL WHERE id=?`).run(
      nowIso(),
      next,
      acc.id
    );
    console.log(
      `[engine] sent msg#${msg.id} via "${acc.name}" -> ${lead.email}` +
        (res.preview ? `  preview: ${res.preview}` : '')
    );
    return true;
  } catch (err) {
    const message = String(err?.message || err);
    db.prepare(`UPDATE messages SET status='failed', error=?, subject=?, body=? WHERE id=?`).run(
      message,
      subject,
      text,
      msg.id
    );
    db.prepare(`UPDATE accounts SET last_error=? WHERE id=?`).run(message, acc.id);
    console.warn(`[engine] FAILED msg#${msg.id} via "${acc.name}": ${message}`);
    return true; // we did do work this tick
  }
}

export async function tickOnce() {
  if (ticking) return;
  ticking = true;
  lastTickAt = nowIso();
  try {
    const accounts = db.prepare(`SELECT * FROM accounts WHERE status='active'`).all();
    const now = Date.now();
    for (const acc of accounts) {
      if (acc.next_due_at && Date.parse(acc.next_due_at) > now) continue; // pacing
      if (sentTodayCount(acc.id) >= effectiveDailyCap(acc)) continue;     // throttle/cap
      await sendOneFor(acc); // at most one email per mailbox per tick
    }
    markCompletedCampaigns();
  } finally {
    ticking = false;
  }
}

export function startEngine(intervalMs = 4000) {
  if (timer) return;
  recoverStuck();
  timer = setInterval(() => {
    if (running) tickOnce().catch((e) => console.error('[engine] tick error:', e));
  }, intervalMs);
  console.log(`[engine] started (tick every ${intervalMs}ms, ${running ? 'running' : 'paused'})`);
}

export function pauseEngine() {
  running = false;
}
export function resumeEngine() {
  running = true;
}
export function engineState() {
  return { running, lastTickAt };
}
