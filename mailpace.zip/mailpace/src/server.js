import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { db, nowIso, sentTodayCount, effectiveDailyCap } from './db.js';
import { verifyAccount, isDryRun } from './mailer.js';
import {
  startEngine,
  pauseEngine,
  resumeEngine,
  engineState,
  tickOnce,
} from './engine.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const TICK_MS = Number(process.env.ENGINE_TICK_MS) || 4000;

const app = express();
app.use(express.json({ limit: '4mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Small helper to wrap async route handlers and funnel errors to one place.
const wrap = (fn) => (req, res) =>
  Promise.resolve(fn(req, res)).catch((err) => {
    console.error(err);
    res.status(500).json({ error: String(err?.message || err) });
  });

const intBool = (v, d = 0) => (v === undefined || v === null ? d : v ? 1 : 0);

/* ----------------------------------------------------------------------- *
 *  STATS / OVERVIEW
 * ----------------------------------------------------------------------- */
app.get('/api/stats', (req, res) => {
  const one = (sql, ...a) => db.prepare(sql).get(...a).c;
  const totals = {
    accounts: one(`SELECT COUNT(*) c FROM accounts`),
    activeAccounts: one(`SELECT COUNT(*) c FROM accounts WHERE status='active'`),
    leads: one(`SELECT COUNT(*) c FROM leads`),
    campaigns: one(`SELECT COUNT(*) c FROM campaigns`),
    runningCampaigns: one(`SELECT COUNT(*) c FROM campaigns WHERE status='running'`),
    queued: one(`SELECT COUNT(*) c FROM messages WHERE status='queued'`),
    sending: one(`SELECT COUNT(*) c FROM messages WHERE status='sending'`),
    sent: one(`SELECT COUNT(*) c FROM messages WHERE status='sent'`),
    failed: one(`SELECT COUNT(*) c FROM messages WHERE status='failed'`),
    sentToday: one(
      `SELECT COUNT(*) c FROM messages WHERE status='sent' AND substr(sent_at,1,10)=?`,
      new Date().toISOString().slice(0, 10)
    ),
  };

  const accounts = db.prepare(`SELECT * FROM accounts ORDER BY id`).all().map((a) => ({
    id: a.id,
    name: a.name,
    from_email: a.from_email,
    status: a.status,
    sentToday: sentTodayCount(a.id),
    cap: effectiveDailyCap(a),
    daily_limit: a.daily_limit,
    warmup_enabled: !!a.warmup_enabled,
    next_due_at: a.next_due_at,
    last_sent_at: a.last_sent_at,
    last_error: a.last_error,
  }));

  res.json({
    engine: { ...engineState(), dryRun: isDryRun(), tickMs: TICK_MS },
    totals,
    accounts,
  });
});

/* ----------------------------------------------------------------------- *
 *  ACCOUNTS (mailboxes)
 * ----------------------------------------------------------------------- */
app.get('/api/accounts', (req, res) => {
  const rows = db.prepare(`SELECT * FROM accounts ORDER BY id`).all().map((a) => ({
    ...a,
    smtp_pass: a.smtp_pass ? '********' : '', // never expose stored passwords
    sentToday: sentTodayCount(a.id),
    cap: effectiveDailyCap(a),
  }));
  res.json(rows);
});

app.post('/api/accounts', (req, res) => {
  const b = req.body || {};
  for (const f of ['name', 'from_email', 'smtp_host', 'smtp_user', 'smtp_pass']) {
    if (!b[f]) return res.status(400).json({ error: `Missing required field: ${f}` });
  }
  const warmup = intBool(b.warmup_enabled, 1);
  const info = db
    .prepare(
      `INSERT INTO accounts
       (name, from_name, from_email, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass,
        daily_limit, min_gap_seconds, max_gap_seconds,
        warmup_enabled, warmup_initial, warmup_increment, warmup_started_at,
        status, created_at)
       VALUES (@name,@from_name,@from_email,@smtp_host,@smtp_port,@smtp_secure,@smtp_user,@smtp_pass,
        @daily_limit,@min_gap_seconds,@max_gap_seconds,
        @warmup_enabled,@warmup_initial,@warmup_increment,@warmup_started_at,
        'active',@created_at)`
    )
    .run({
      name: b.name,
      from_name: b.from_name || '',
      from_email: b.from_email,
      smtp_host: b.smtp_host,
      smtp_port: Number(b.smtp_port) || 587,
      smtp_secure: intBool(b.smtp_secure, Number(b.smtp_port) === 465 ? 1 : 0),
      smtp_user: b.smtp_user,
      smtp_pass: b.smtp_pass,
      daily_limit: Number(b.daily_limit) || 50,
      min_gap_seconds: Number(b.min_gap_seconds) || 90,
      max_gap_seconds: Number(b.max_gap_seconds) || 300,
      warmup_enabled: warmup,
      warmup_initial: Number(b.warmup_initial) || 5,
      warmup_increment: Number(b.warmup_increment) || 5,
      warmup_started_at: warmup ? nowIso() : null,
      created_at: nowIso(),
    });
  res.json(db.prepare(`SELECT * FROM accounts WHERE id=?`).get(info.lastInsertRowid));
});

app.put('/api/accounts/:id', (req, res) => {
  const acc = db.prepare(`SELECT * FROM accounts WHERE id=?`).get(req.params.id);
  if (!acc) return res.status(404).json({ error: 'Account not found' });
  const b = req.body || {};
  // Only overwrite the password if a new, non-masked one is supplied.
  const newPass = b.smtp_pass && b.smtp_pass !== '********' ? b.smtp_pass : acc.smtp_pass;
  const warmup = intBool(b.warmup_enabled ?? acc.warmup_enabled, acc.warmup_enabled);
  db.prepare(
    `UPDATE accounts SET
       name=@name, from_name=@from_name, from_email=@from_email,
       smtp_host=@smtp_host, smtp_port=@smtp_port, smtp_secure=@smtp_secure,
       smtp_user=@smtp_user, smtp_pass=@smtp_pass,
       daily_limit=@daily_limit, min_gap_seconds=@min_gap_seconds, max_gap_seconds=@max_gap_seconds,
       warmup_enabled=@warmup_enabled, warmup_initial=@warmup_initial, warmup_increment=@warmup_increment,
       warmup_started_at=@warmup_started_at
     WHERE id=@id`
  ).run({
    id: acc.id,
    name: b.name ?? acc.name,
    from_name: b.from_name ?? acc.from_name,
    from_email: b.from_email ?? acc.from_email,
    smtp_host: b.smtp_host ?? acc.smtp_host,
    smtp_port: Number(b.smtp_port ?? acc.smtp_port),
    smtp_secure: intBool(b.smtp_secure ?? acc.smtp_secure, acc.smtp_secure),
    smtp_user: b.smtp_user ?? acc.smtp_user,
    smtp_pass: newPass,
    daily_limit: Number(b.daily_limit ?? acc.daily_limit),
    min_gap_seconds: Number(b.min_gap_seconds ?? acc.min_gap_seconds),
    max_gap_seconds: Number(b.max_gap_seconds ?? acc.max_gap_seconds),
    warmup_enabled: warmup,
    warmup_initial: Number(b.warmup_initial ?? acc.warmup_initial),
    warmup_increment: Number(b.warmup_increment ?? acc.warmup_increment),
    warmup_started_at: warmup ? acc.warmup_started_at || nowIso() : null,
  });
  res.json(db.prepare(`SELECT * FROM accounts WHERE id=?`).get(acc.id));
});

app.delete('/api/accounts/:id', (req, res) => {
  db.prepare(`DELETE FROM accounts WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
});

app.post('/api/accounts/:id/pause', (req, res) => {
  db.prepare(`UPDATE accounts SET status='paused' WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
});
app.post('/api/accounts/:id/resume', (req, res) => {
  db.prepare(`UPDATE accounts SET status='active', last_error=NULL WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
});

// Verify SMTP login without sending anything.
app.post(
  '/api/accounts/:id/test',
  wrap(async (req, res) => {
    const acc = db.prepare(`SELECT * FROM accounts WHERE id=?`).get(req.params.id);
    if (!acc) return res.status(404).json({ error: 'Account not found' });
    try {
      await verifyAccount(acc);
      db.prepare(`UPDATE accounts SET last_error=NULL WHERE id=?`).run(acc.id);
      res.json({ ok: true, dryRun: isDryRun() });
    } catch (err) {
      const message = String(err?.message || err);
      db.prepare(`UPDATE accounts SET last_error=? WHERE id=?`).run(message, acc.id);
      res.status(400).json({ ok: false, error: message });
    }
  })
);

/* ----------------------------------------------------------------------- *
 *  LEADS
 * ----------------------------------------------------------------------- */
app.get('/api/leads', (req, res) => {
  res.json(db.prepare(`SELECT * FROM leads ORDER BY id DESC LIMIT 1000`).all());
});

// Very forgiving CSV parser: optional header row; columns email,first_name,last_name,company.
function parseCsv(text) {
  const lines = String(text)
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (!lines.length) return [];
  let cols = ['email', 'first_name', 'last_name', 'company'];
  let start = 0;
  if (/email/i.test(lines[0])) {
    cols = lines[0].split(',').map((c) => c.trim().toLowerCase().replace(/\s+/g, '_'));
    start = 1;
  }
  const out = [];
  for (let i = start; i < lines.length; i++) {
    const parts = lines[i].split(',').map((p) => p.trim());
    const row = {};
    cols.forEach((c, idx) => (row[c] = parts[idx] || ''));
    if (row.email && /.+@.+\..+/.test(row.email)) out.push(row);
  }
  return out;
}

app.post('/api/leads', (req, res) => {
  const b = req.body || {};
  let rows = [];
  if (Array.isArray(b.leads)) rows = b.leads;
  else if (typeof b.csv === 'string') rows = parseCsv(b.csv);
  else if (b.email) rows = [b];
  else return res.status(400).json({ error: 'Provide leads[], csv text, or a single lead.' });

  const insert = db.prepare(
    `INSERT OR IGNORE INTO leads (email, first_name, last_name, company, created_at)
     VALUES (?,?,?,?,?)`
  );
  let inserted = 0;
  const tx = db.transaction((items) => {
    for (const r of items) {
      if (!r.email) continue;
      const info = insert.run(
        String(r.email).toLowerCase().trim(),
        r.first_name || '',
        r.last_name || '',
        r.company || '',
        nowIso()
      );
      inserted += info.changes;
    }
  });
  tx(rows);
  res.json({ received: rows.length, inserted, skipped: rows.length - inserted });
});

app.delete('/api/leads/:id', (req, res) => {
  db.prepare(`DELETE FROM leads WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
});

/* ----------------------------------------------------------------------- *
 *  CAMPAIGNS
 * ----------------------------------------------------------------------- */
function campaignWithCounts(c) {
  const counts = db
    .prepare(
      `SELECT
         SUM(status='queued')  AS queued,
         SUM(status='sending') AS sending,
         SUM(status='sent')    AS sent,
         SUM(status='failed')  AS failed,
         COUNT(*)              AS total
       FROM messages WHERE campaign_id=?`
    )
    .get(c.id);
  return {
    ...c,
    counts: {
      queued: counts.queued || 0,
      sending: counts.sending || 0,
      sent: counts.sent || 0,
      failed: counts.failed || 0,
      total: counts.total || 0,
    },
  };
}

app.get('/api/campaigns', (req, res) => {
  res.json(db.prepare(`SELECT * FROM campaigns ORDER BY id DESC`).all().map(campaignWithCounts));
});

app.get('/api/campaigns/:id', (req, res) => {
  const c = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Campaign not found' });
  res.json(campaignWithCounts(c));
});

app.post('/api/campaigns', (req, res) => {
  const b = req.body || {};
  for (const f of ['name', 'subject', 'body']) {
    if (!b[f]) return res.status(400).json({ error: `Missing required field: ${f}` });
  }
  const info = db
    .prepare(`INSERT INTO campaigns (name, subject, body, status, created_at) VALUES (?,?,?,'draft',?)`)
    .run(b.name, b.subject, b.body, nowIso());
  res.json(db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(info.lastInsertRowid));
});

app.put('/api/campaigns/:id', (req, res) => {
  const c = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Campaign not found' });
  const b = req.body || {};
  db.prepare(`UPDATE campaigns SET name=?, subject=?, body=? WHERE id=?`).run(
    b.name ?? c.name,
    b.subject ?? c.subject,
    b.body ?? c.body,
    c.id
  );
  res.json(db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(c.id));
});

app.delete('/api/campaigns/:id', (req, res) => {
  db.prepare(`DELETE FROM campaigns WHERE id=?`).run(req.params.id);
  res.json({ ok: true });
});

// Build the send queue: one message per lead (skipping any already queued).
app.post('/api/campaigns/:id/enqueue', (req, res) => {
  const c = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Campaign not found' });
  const ids = Array.isArray(req.body?.lead_ids) && req.body.lead_ids.length
    ? req.body.lead_ids
    : db.prepare(`SELECT id FROM leads`).all().map((r) => r.id);

  const insert = db.prepare(
    `INSERT OR IGNORE INTO messages (campaign_id, lead_id, status, queued_at) VALUES (?,?,'queued',?)`
  );
  let added = 0;
  const tx = db.transaction((leadIds) => {
    for (const lid of leadIds) added += insert.run(c.id, lid, nowIso()).changes;
  });
  tx(ids);
  res.json({ added, ...campaignWithCounts(c) });
});

app.post('/api/campaigns/:id/start', (req, res) => {
  const c = db.prepare(`SELECT * FROM campaigns WHERE id=?`).get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Campaign not found' });
  const queued = db
    .prepare(`SELECT COUNT(*) c FROM messages WHERE campaign_id=? AND status IN ('queued','sending')`)
    .get(c.id).c;
  if (!queued) return res.status(400).json({ error: 'Nothing queued. Add leads and enqueue first.' });
  const active = db.prepare(`SELECT COUNT(*) c FROM accounts WHERE status='active'`).get().c;
  if (!active) return res.status(400).json({ error: 'No active mailbox. Add a mailbox first.' });
  db.prepare(`UPDATE campaigns SET status='running' WHERE id=?`).run(c.id);
  res.json({ ok: true });
});

app.post('/api/campaigns/:id/pause', (req, res) => {
  db.prepare(`UPDATE campaigns SET status='paused' WHERE id=? AND status='running'`).run(req.params.id);
  res.json({ ok: true });
});

app.get('/api/campaigns/:id/messages', (req, res) => {
  const { status } = req.query;
  const base = `SELECT m.*, l.email AS lead_email, l.first_name, a.name AS account_name
                FROM messages m
                JOIN leads l ON l.id=m.lead_id
                LEFT JOIN accounts a ON a.id=m.account_id
                WHERE m.campaign_id=?`;
  const rows = status
    ? db.prepare(`${base} AND m.status=? ORDER BY m.id DESC LIMIT 500`).all(req.params.id, status)
    : db.prepare(`${base} ORDER BY m.id DESC LIMIT 500`).all(req.params.id);
  res.json(rows);
});

/* ----------------------------------------------------------------------- *
 *  ENGINE CONTROL
 * ----------------------------------------------------------------------- */
app.get('/api/engine', (req, res) =>
  res.json({ ...engineState(), dryRun: isDryRun(), tickMs: TICK_MS })
);
app.post('/api/engine/pause', (req, res) => {
  pauseEngine();
  res.json(engineState());
});
app.post('/api/engine/resume', (req, res) => {
  resumeEngine();
  res.json(engineState());
});
// Force an immediate tick (handy for demos/tests instead of waiting for the timer).
app.post(
  '/api/engine/tick',
  wrap(async (req, res) => {
    await tickOnce();
    res.json({ ok: true });
  })
);

/* ----------------------------------------------------------------------- */
app.listen(PORT, () => {
  console.log(`\n  MailPace running:  http://localhost:${PORT}`);
  console.log(`  Mode:              ${isDryRun() ? 'DRY RUN (no real emails)' : 'LIVE (real SMTP)'}`);
  startEngine(TICK_MS);
});
