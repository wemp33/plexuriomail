// Loads demo data so you can watch the engine work immediately (great with DRY_RUN=1).
//   node src/seed.js
import 'dotenv/config';
import { db, nowIso } from './db.js';

console.log('Seeding demo data…');

db.exec('DELETE FROM messages; DELETE FROM campaigns; DELETE FROM leads; DELETE FROM accounts;');

const insAcc = db.prepare(`INSERT INTO accounts
  (name, from_name, from_email, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass,
   daily_limit, min_gap_seconds, max_gap_seconds,
   warmup_enabled, warmup_initial, warmup_increment, warmup_started_at, status, created_at)
  VALUES (@name,@from_name,@from_email,@smtp_host,@smtp_port,@smtp_secure,@smtp_user,@smtp_pass,
   @daily_limit,@min_gap_seconds,@max_gap_seconds,
   @warmup_enabled,@warmup_initial,@warmup_increment,@warmup_started_at,'active',@created_at)`);

// Mailbox A: fresh, warming up -> today's cap is just 5 (demonstrates warmup throttling).
insAcc.run({
  name: 'Sales — Jane', from_name: 'Jane Doe', from_email: 'jane@demo.test',
  smtp_host: 'smtp.example.com', smtp_port: 587, smtp_secure: 0,
  smtp_user: 'jane@demo.test', smtp_pass: 'dry-run',
  daily_limit: 50, min_gap_seconds: 2, max_gap_seconds: 4,
  warmup_enabled: 1, warmup_initial: 5, warmup_increment: 5, warmup_started_at: nowIso(),
  created_at: nowIso(),
});
// Mailbox B: established, no warmup, higher cap (demonstrates rotation + higher throughput).
insAcc.run({
  name: 'Founder — Sam', from_name: 'Sam Lee', from_email: 'sam@demo.test',
  smtp_host: 'smtp.example.com', smtp_port: 587, smtp_secure: 0,
  smtp_user: 'sam@demo.test', smtp_pass: 'dry-run',
  daily_limit: 30, min_gap_seconds: 2, max_gap_seconds: 5,
  warmup_enabled: 0, warmup_initial: 5, warmup_increment: 5, warmup_started_at: null,
  created_at: nowIso(),
});

const leads = [
  ['amir@northwind.test','Amir','Khan','Northwind'],
  ['bea@globex.test','Bea','Ortiz','Globex'],
  ['carl@initech.test','Carl','Reyes','Initech'],
  ['dana@umbrella.test','Dana','Wu','Umbrella'],
  ['ed@hooli.test','Ed','Park','Hooli'],
  ['fiona@acme.test','Fiona','Ali','Acme'],
  ['gabe@stark.test','Gabe','Nwosu','Stark Industries'],
  ['hana@wayne.test','Hana','Cohen','Wayne Enterprises'],
  ['ivan@soylent.test','Ivan','Petrov','Soylent'],
  ['jo@piedpiper.test','Jo','Tanaka','Pied Piper'],
  ['kira@cyberdyne.test','Kira','Mbeki','Cyberdyne'],
  ['leo@tyrell.test','Leo','Santos','Tyrell'],
];
const insLead = db.prepare(`INSERT INTO leads (email,first_name,last_name,company,created_at) VALUES (?,?,?,?,?)`);
const leadIds = leads.map((l) => insLead.run(l[0], l[1], l[2], l[3], nowIso()).lastInsertRowid);

const cid = db
  .prepare(`INSERT INTO campaigns (name,subject,body,status,created_at) VALUES (?,?,?,'running',?)`)
  .run(
    'June outreach',
    'Quick question about {{company}}, {{first_name}}',
    'Hi {{first_name}},\n\nI saw what {{company}} is doing and had a quick idea I think could help.\nWorth a 10-minute chat this week?\n\nBest,\nJane',
    nowIso()
  ).lastInsertRowid;

const insMsg = db.prepare(`INSERT INTO messages (campaign_id,lead_id,status,queued_at) VALUES (?,?,'queued',?)`);
leadIds.forEach((lid) => insMsg.run(cid, lid, nowIso()));

console.log(`Seeded 2 mailboxes, ${leads.length} leads, 1 running campaign with ${leads.length} queued emails.`);
console.log('Start the app (npm start) and open the dashboard to watch them send.');
