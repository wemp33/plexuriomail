// Thin wrapper around nodemailer. One transport per mailbox.
// In DRY_RUN mode every transport is a no-network "jsonTransport" so you can
// exercise the whole engine without sending a single real email.
import nodemailer from 'nodemailer';

const DRY_RUN = process.env.DRY_RUN === '1';

export function isDryRun() {
  return DRY_RUN;
}

function buildTransport(acc) {
  if (DRY_RUN) {
    // Serializes the message to JSON instead of hitting the network.
    return nodemailer.createTransport({ jsonTransport: true });
  }
  return nodemailer.createTransport({
    host: acc.smtp_host,
    port: Number(acc.smtp_port),
    secure: !!acc.smtp_secure, // true for 465, false for 587/25 (STARTTLS)
    auth: { user: acc.smtp_user, pass: acc.smtp_pass },
    // Reasonable timeouts so a dead host fails fast instead of stalling the engine.
    connectionTimeout: 15000,
    greetingTimeout: 10000,
    socketTimeout: 20000,
  });
}

// Confirms the SMTP credentials work (login + handshake). Returns true or throws.
export async function verifyAccount(acc) {
  if (DRY_RUN) return true;
  const transport = buildTransport(acc);
  await transport.verify();
  return true;
}

function fromHeader(acc) {
  return acc.from_name ? `"${acc.from_name}" <${acc.from_email}>` : acc.from_email;
}

export async function sendEmail(acc, { to, subject, text, html }) {
  const transport = buildTransport(acc);
  const info = await transport.sendMail({
    from: fromHeader(acc),
    to,
    subject,
    text,
    html,
  });
  return {
    messageId: info.messageId,
    // Ethereal test accounts return a preview URL; real SMTP usually won't.
    preview: nodemailer.getTestMessageUrl?.(info) || null,
  };
}
