import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DB_PATH = process.env.DB_PATH
  ? path.resolve(ROOT, process.env.DB_PATH)
  : path.join(ROOT, 'data', 'mailpace.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export const db = await openDatabase(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

async function openDatabase(file) {
  try {
    const { default: Better } = await import('better-sqlite3');
    return new Better(file);
  } catch {
    const { DatabaseSync } = await import('node:sqlite');
    return wrapNodeSqlite(new DatabaseSync(file));
  }
}

function wrapNodeSqlite(d) {
  return {
    pragma: (s) => d.exec(`PRAGMA ${s};`),
    exec: (s) => d.exec(s),
    prepare: (sql) => {
      const st = d.prepare(sql);
      return {
        get: (...a) => st.get(...a),
        all: (...a) => st.all(...a),
        run: (...a) => {
          const r = st.run(...a);
          return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
        },
      };
    },
    transaction: (fn) => (...args) => {
      d.exec('BEGIN');
      try {
        const r = fn(...args);
        d.exec('COMMIT');
        return r;
      } catch (e) {
        try { d.exec('ROLLBACK'); } catch {}
        throw e;
      }
    },
    close: () => d.close(),
  };
}

db.exec(`
CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  from_name TEXT,
  from_email TEXT NOT NULL,
  smtp_host TEXT NOT NULL,
  smtp_port INTEGER NOT NULL DEFAULT 587,
  smtp_secure INTEGER NOT NULL DEFAULT 0,
  smtp_user TEXT NOT NULL,
  smtp_pass TEXT NOT NULL,
  daily_limit INTEGER NOT NULL DEFAULT 50,
  min_gap_seconds INTEGER NOT NULL DEFAULT 90,
  max_gap_seconds INTEGER NOT NULL DEFAULT 300,
  warmup_enabled INTEGER NOT NULL DEFAULT 1,
  warmup_initial INTEGER NOT NULL DEFAULT 5,
  warmup_increment INTEGER NOT NULL DEFAULT 5,
  warmup_started_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  last_error TEXT,
  last_sent_at TEXT,
  next_due_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  first_name TEXT, last_name TEXT, company TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS campaigns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  campaign_id INTEGER NOT NULL,
  lead_id INTEGER NOT NULL,
  account_id INTEGER,
  status TEXT NOT NULL DEFAULT 'queued',
  subject TEXT, body TEXT, error TEXT, preview_url TEXT,
  queued_at TEXT NOT NULL, sent_at TEXT,
  FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE,
  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  UNIQUE (campaign_id, lead_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_status ON messages(status);
CREATE INDEX IF NOT EXISTS idx_messages_campaign ON messages(campaign_id);
CREATE INDEX IF NOT EXISTS idx_messages_account ON messages(account_id, status, sent_at);
`);

export const nowIso = () => new Date().toISOString();
export const todayKey = () => new Date().toISOString().slice(0, 10);

export function sentTodayCount(accountId) {
  return db.prepare(
    `SELECT COUNT(*) AS c FROM messages
     WHERE account_id = ? AND status = 'sent' AND substr(sent_at, 1, 10) = ?`
  ).get(accountId, todayKey()).c;
}

export function effectiveDailyCap(acc) {
  if (!acc.warmup_enabled) return acc.daily_limit;
  const start = acc.warmup_started_at || acc.created_at;
  const days = Math.max(0, Math.floor((Date.now() - Date.parse(start)) / 86400000));
  const ramped = acc.warmup_initial + acc.warmup_increment * days;
  return Math.min(ramped, acc.daily_limit);
}
