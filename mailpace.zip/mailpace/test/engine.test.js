// Verifies the engine's intelligence: daily caps/warmup throttling, account
// rotation, and template rendering — all without sending real email.
// Run with:  node test/engine.test.js   (or: npm run test:engine)
import assert from 'node:assert';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

// Force dry-run + an isolated throwaway DB BEFORE importing the app modules.
process.env.DRY_RUN = '1';
const tmpDb = path.join(os.tmpdir(), `mailpace-test-${Date.now()}.db`);
process.env.DB_PATH = tmpDb;

const { db, nowIso, sentTodayCount, effectiveDailyCap } = await import('../src/db.js');
const { tickOnce, renderTemplate } = await import('../src/engine.js');

let passed = 0;
const ok = (label) => { console.log('  ✓ ' + label); passed++; };

// --- template rendering ---------------------------------------------------
const rendered = renderTemplate('Hi {{first_name}} at {{company}} ({{missing}})', {
  first_name: 'Amir', company: 'Northwind',
});
assert.strictEqual(rendered, 'Hi Amir at Northwind ()');
ok('renderTemplate fills tokens and blanks unknown ones');

// --- seed an isolated scenario -------------------------------------------
const insAcc = db.prepare(`INSERT INTO accounts
  (name,from_name,from_email,smtp_host,smtp_port,smtp_secure,smtp_user,smtp_pass,
   daily_limit,min_gap_seconds,max_gap_seconds,warmup_enabled,warmup_initial,warmup_increment,
   warmup_started_at,status,created_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?)`);

// Mailbox A: warming up today -> cap should be exactly 5.
const accA = insAcc.run('A','A','a@test','h',587,0,'a','p', 50, 0,0, 1, 5,5, nowIso(), nowIso()).lastInsertRowid;
// Mailbox B: no warmup, cap 50, gaps 0 so it is always "due".
const accB = insAcc.run('B','B','b@test','h',587,0,'b','p', 50, 0,0, 0, 5,5, null, nowIso()).lastInsertRowid;

assert.strictEqual(effectiveDailyCap(db.prepare('SELECT * FROM accounts WHERE id=?').get(accA)), 5,
  'warmup cap should be 5 on day one');
ok('warmup ramp computes day-one cap of 5');
assert.strictEqual(effectiveDailyCap(db.prepare('SELECT * FROM accounts WHERE id=?').get(accB)), 50);
ok('non-warmup cap equals daily_limit (50)');

const insLead = db.prepare(`INSERT INTO leads (email,first_name,last_name,company,created_at) VALUES (?,?,?,?,?)`);
const N = 20;
const leadIds = [];
for (let i = 0; i < N; i++) leadIds.push(insLead.run(`lead${i}@test`, `F${i}`, 'L', 'Co', nowIso()).lastInsertRowid);

const cid = db.prepare(`INSERT INTO campaigns (name,subject,body,status,created_at) VALUES (?,?,?,'running',?)`)
  .run('C', 'Hi {{first_name}}', 'Body for {{first_name}}', nowIso()).lastInsertRowid;
const insMsg = db.prepare(`INSERT INTO messages (campaign_id,lead_id,status,queued_at) VALUES (?,?,'queued',?)`);
leadIds.forEach((lid) => insMsg.run(cid, lid, nowIso()));

// --- run the engine to completion ----------------------------------------
for (let i = 0; i < 100; i++) {
  await tickOnce();
  const left = db.prepare(`SELECT COUNT(*) c FROM messages WHERE status='queued'`).get().c;
  if (!left) break;
}

const sentA = sentTodayCount(accA);
const sentB = sentTodayCount(accB);
const totalSent = db.prepare(`SELECT COUNT(*) c FROM messages WHERE status='sent'`).get().c;

// Throttling: mailbox A must never exceed its warmup cap of 5.
assert.ok(sentA <= 5, `A sent ${sentA}, expected <= 5 (cap)`);
ok(`throttling: warming mailbox A capped at ${sentA}/5`);

// Rotation: both mailboxes should have carried load.
assert.ok(sentA > 0 && sentB > 0, `expected both mailboxes used (A=${sentA}, B=${sentB})`);
ok(`rotation: load spread across both mailboxes (A=${sentA}, B=${sentB})`);

// Throughput: A(5) + B(up to 50) >= 20 leads, so all 20 should send.
assert.strictEqual(totalSent, N, `expected all ${N} sent, got ${totalSent}`);
ok(`all ${N} queued emails delivered`);
assert.strictEqual(sentA + sentB, N);
ok('per-mailbox counts reconcile with total');

// Completion: campaign should be auto-marked completed (no work left).
const status = db.prepare('SELECT status FROM campaigns WHERE id=?').get(cid).status;
assert.strictEqual(status, 'completed');
ok('campaign auto-completes when queue drains');

db.close();
fs.rmSync(tmpDb, { force: true });
fs.rmSync(tmpDb + '-wal', { force: true });
fs.rmSync(tmpDb + '-shm', { force: true });

console.log(`\nAll ${passed} checks passed.`);
