# MailPace

A lightweight, self-hosted cold-email sender — the core of a tool like Instantly.ai, minus the bloat. You add your own mailboxes (SMTP), import leads, write a campaign, and a backend engine sends the emails **intelligently** so they pace like a human instead of blasting out in one suspicious burst.

It's one Node process: an Express API + a web dashboard + a SQLite database. No external services to set up.

---

## What "intelligent sending" means here

The engine wakes up every few seconds and, for each mailbox, decides whether it may send **one** email right now. A mailbox sends only when all of these hold:

- **Throttling / daily caps** — each mailbox has a `daily_limit`. Once it hits today's cap, it stops until tomorrow.
- **Warmup ramp** — a new mailbox starts at a low daily cap (e.g. 5) and increases it a little each day (`+5/day`) up to its `daily_limit`. This mimics a mailbox that's gradually building reputation, which protects deliverability.
- **Account rotation** — the engine loops mailbox-by-mailbox and pulls the oldest queued email, so volume naturally spreads across every active mailbox instead of hammering one.
- **Human-like pacing** — after each send, a mailbox waits a *random* gap (e.g. 90–300s) before it's eligible again. No robotic fixed intervals.

The result: emails trickle out, spread across mailboxes, capped per day, ramping over time.

---

## Quick start

```bash
cd mailpace
npm install
cp .env.example .env      # Windows: copy .env.example .env
npm run seed              # optional: load demo mailboxes, leads & a running campaign
npm start
```

Open **http://localhost:3000**.

`.env` ships with `DRY_RUN=1`, so out of the box **no real emails are sent** — the engine runs the full pipeline and logs each "send" so you can watch throttling, rotation and warmup work. If you ran `npm run seed`, the Overview tab will start showing emails moving from *queued* to *sent* within seconds.

When you're ready to send for real, set `DRY_RUN=0` in `.env` and restart.

---

## Connecting a real mailbox

In the **Mailboxes** tab, add an SMTP account. Common settings:

| Provider        | Host                  | Port | Security        | Password |
|-----------------|-----------------------|------|-----------------|----------|
| Gmail / Workspace | `smtp.gmail.com`     | 587  | STARTTLS        | **App password** (not your login) |
| Outlook / M365  | `smtp.office365.com`  | 587  | STARTTLS        | App password |
| Custom / other  | your host             | 587 or 465 | STARTTLS or SSL/TLS | mailbox password |

> Gmail and Outlook require an **app password** with 2-factor auth enabled — your normal password will be rejected. Generate one in your account's security settings and paste it into the password field.

Click **Test** on a mailbox to verify the SMTP login before sending. Per-mailbox **daily limit**, **min/max gap**, and **warmup** are all editable.

---

## Sending a campaign

1. **Mailboxes** — add at least one mailbox and Test it.
2. **Leads** — paste CSV (header optional). Recognized columns: `email, first_name, last_name, company`.
3. **Campaigns** — create one. Personalize the subject/body with `{{first_name}}`, `{{last_name}}`, `{{company}}`, `{{email}}`.
4. On the campaign, click **Add all leads to queue**, then **Start sending**.
5. Watch it on **Overview** (pace toward each mailbox's cap) or expand the campaign to see per-recipient status. Pause the whole engine anytime with the toggle in the header.

---

## How it's built

```
mailpace/
├─ src/
│  ├─ server.js   Express API + serves the dashboard, starts the engine
│  ├─ engine.js   the sending loop: throttling, caps, warmup, rotation, pacing
│  ├─ mailer.js   nodemailer wrapper (real SMTP, or jsonTransport in dry-run)
│  ├─ db.js       SQLite schema + helpers (accounts, leads, campaigns, messages)
│  └─ seed.js     demo data
├─ public/
│  └─ index.html  the single-file dashboard (no build step)
├─ test/
│  └─ engine.test.js  asserts caps, rotation, warmup, completion
└─ .env.example
```

Run the engine checks with `npm run test:engine`.

### Key API endpoints

```
GET  /api/stats                       dashboard totals + per-mailbox pace
POST /api/accounts                    add a mailbox      | POST /api/accounts/:id/test
POST /api/leads                       { csv } or { leads:[…] }
POST /api/campaigns                   { name, subject, body }
POST /api/campaigns/:id/enqueue       build the send queue from leads
POST /api/campaigns/:id/start | /pause
POST /api/engine/pause | /resume      | POST /api/engine/tick (send immediately)
```

---

## Notes & limits

This is a clean MVP focused on the two things you asked for — **throttling/daily caps** and **account rotation + warmup** — plus human-like pacing. Natural extensions: sending windows by recipient timezone, multi-step follow-up sequences, reply/bounce detection to auto-stop a thread, and open tracking. The schema and engine are structured to make these straightforward to add.

SMTP passwords are stored in the local SQLite file in plain text (fine for a personal, single-machine tool). If you deploy this for a team, move secrets to encrypted storage and put it behind auth.

---

## Responsible use

Cold email is regulated. Before sending to real people, make sure you comply with the laws that apply to you (e.g. **CAN-SPAM** in the US, **GDPR/PECR** in the EU/UK): only email people you have a lawful basis to contact, identify yourself honestly, include a real physical address, and honor opt-outs promptly. This tool gives you the controls; using them lawfully is on you.
